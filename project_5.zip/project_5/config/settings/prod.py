from .base import *

ALLOWED_HOSTS = ['43.200.23.210']
STATIC_ROOT = BASE_DIR / 'static/'
STATICFILES_DIRS = []
DEBUG = False