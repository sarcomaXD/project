from django.contrib import admin
from .models import Organization, Volunteer

# Register your models here.
admin.site.register(Organization)
admin.site.register(Volunteer)
